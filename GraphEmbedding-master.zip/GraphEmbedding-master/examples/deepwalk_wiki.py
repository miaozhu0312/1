
import numpy as np
import pandas as pd

from ge.classify import read_node_label, Classifier
from ge import DeepWalk
from sklearn.linear_model import LogisticRegression

import matplotlib.pyplot as plt
import networkx as nx
from sklearn.manifold import TSNE
from config_parm import *



def evaluate_embeddings(embeddings):
    X, Y = read_node_label('../data/wiki/wiki_labels.txt')
    tr_frac = 0.8
    print("Training classifier using {:.2f}% nodes...".format(
        tr_frac * 100))
    clf = Classifier(embeddings=embeddings, clf=LogisticRegression())
    clf.split_train_evaluate(X, Y, tr_frac)


def plot_embeddings(embeddings,):
    X, Y = read_node_label('../data/wiki/wiki_labels.txt')

    emb_list = []
    for k in X:
        emb_list.append(embeddings[k])
    emb_list = np.array(emb_list)

    model = TSNE(n_components=2)
    node_pos = model.fit_transform(emb_list)

    color_idx = {}
    for i in range(len(X)):
        color_idx.setdefault(Y[i][0], [])
        color_idx[Y[i][0]].append(i)

    for c, idx in color_idx.items():
        plt.scatter(node_pos[idx, 0], node_pos[idx, 1], label=c)
    plt.legend()
    plt.show()


if __name__ == "__main__":
    """
    G = nx.read_edgelist('../data/wiki/Wiki_edgelist.txt',
                         create_using=nx.DiGraph(), nodetype=None, data=[('weight', int)])
    """
    """
    G = nx.read_edgelist('E:\\data\\DDI\\features\\df_smile_target_enzyme.txt',
                         create_using=nx.DiGraph(), nodetype=None, data=[('weight', int)])
    """
    G = nx.read_edgelist('E:\\data\\DDI\\drugbank\\large_scale_knowledge_graph\out.txt',
                         create_using=nx.DiGraph(), nodetype=None, data=[('weight', int)])

    #model = DeepWalk(G, walk_length=10, num_walks=80, workers=1)
    model = DeepWalk(G, walk_length=10, num_walks=20, workers=1)
    model.train(embed_size=drug_embed_size, window_size=5, iter=3)
    embeddings = model.get_embeddings()

    #print("hello bs!")
    #print(type(embeddings))
    #print("hello world!")
    #print("embeddings['DB00006'] is: ")
#    print(embeddings['1397'])
    #print("type(embeddings[DB00006] is : ")
    #print(type(embeddings))
    #print(embeddings['DB00006'].shape)
    #print(type(embeddings['DB00006']))
    #print(embeddings['DB00006'])

    column_list = []
    for i in range(drug_embed_size):
        column_list.append('feature'+str(i))
    dict = pd.DataFrame.from_dict(embeddings, orient = 'index', columns = column_list)
    dict = dict.reset_index().rename(columns = {'index':'Entity'})
    dict.to_csv('E:\\data\\DDI\\embeddings\\large_scale_knowledge_graph\\deepwalk_embeddings_knowledge_graph_noconvert.csv',
                index=False)

    #evaluate_embeddings(embeddings)
    #plot_embeddings(embeddings)
