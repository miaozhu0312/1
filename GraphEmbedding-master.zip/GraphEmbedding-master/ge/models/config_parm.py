#-*- coding:utf-8 -*-
# @author: baisen
# @email: baisenbx@126.com
# @create time: 2021/2/16 9:11
# @software: PyCharm Community Edition

drug_embed_size = 64